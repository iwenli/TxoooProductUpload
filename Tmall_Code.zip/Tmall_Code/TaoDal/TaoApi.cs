﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace TaoDal
{
    public static class TaoApi
    {

        #region 根据商品地址获取商品信息+TaoModel GetItemByUrl(string url)
        /// <summary>
        /// 根据商品地址获取商品信息
        /// </summary>
        /// <param name="url">商品地址</param>
        /// <returns>商品信息</returns>
        public static TaoModel GetItemByUrl(string url)
        {
            Regex taobaoReg = new Regex("item.taobao.com");//淘宝url
            Regex tianmaoReg = new Regex("detail.tmall.com");//天猫
            Regex aliReg = new Regex("detail.1688.com");//阿里巴巴
            Regex jdReg = new Regex("item.jd.com");//京东
            if (taobaoReg.Match(url).Success)
            {
                return GetInfoByTaobaoUrl(url);
            }
            else if (tianmaoReg.Match(url).Success)
            {
                return GetInfoByTmallUrl(url);
            }
            else if (aliReg.Match(url).Success)
            {
                return GetInfoByAli(url);
            }
            else if (jdReg.Match(url).Success)
            {
                return GetInfoByJd(url);
            }
            return null;
        }
        #endregion

        #region 根据Url获取相应字符串+string GetStrByUrl(string url)
        /// <summary>
        /// 根据Url获取相应字符串
        /// </summary>
        /// <param name="url">网址</param>
        /// <returns>网页html代码</returns>
        private static string GetStrByUrl(string url, string encodeing)
        {
            string str = "";
            Encoding ecd = string.IsNullOrEmpty(encodeing) ? Encoding.Default : Encoding.GetEncoding(encodeing);
            try
            {
                WebRequest request = HttpWebRequest.Create(url);
                WebResponse response = request.GetResponse();
                StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding(encodeing));
                str = reader.ReadToEnd();
                reader.Close();
                reader.Dispose();
                response.Close();
            }
            catch (Exception ex)
            {
                str = ex.Message;
            }
            return str;
        }
        #endregion

        #region 浏览器根据url打开页面获取页面内容+StringBuilder GetStrByBorwserUrl(string url)
        /// <summary>
        /// 根据浏览器控件打开页面获取页面内容
        /// </summary>
        /// <param name="url"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        private static StringBuilder GetStrByBorwserUrl(string url)
        {
            StringBuilder sbHml = new StringBuilder();
            System.Windows.Forms.WebBrowser browser = new System.Windows.Forms.WebBrowser();
            browser.Navigate(url);
            while (!WaitWebPageLoad(browser))
            {
                WaitWebPageLoad(browser);
            }
            Encoding encoding = Encoding.GetEncoding(browser.Document.Encoding);
            StreamReader stream = new StreamReader(browser.DocumentStream, encoding);
            sbHml.Append(stream.ReadToEnd());
            return sbHml;
        }

        /// <summary>
        /// 延迟系统时间，但系统又能同时能执行其它任务；
        /// </summary>
        /// <param name="Millisecond"></param>
        private static void Delay(int Millisecond) //延迟系统时间，但系统又能同时能执行其它任务；
        {
            DateTime current = DateTime.Now;
            while (current.AddMilliseconds(Millisecond) > DateTime.Now)
            {
                Application.DoEvents();//转让控制权            
            }
            return;
        }

        /// <summary>
        /// 判断页面是否加载完毕
        /// </summary>
        /// <param name="webBrowser1"></param>
        /// <returns></returns>
        private static bool WaitWebPageLoad(WebBrowser webBrowser1)
        {
            int i = 0;
            string sUrl;
            while (true)
            {
                Delay(50);  //系统延迟50毫秒，够少了吧！             
                if (webBrowser1.ReadyState == WebBrowserReadyState.Complete) //先判断是否发生完成事件。
                {
                    if (!webBrowser1.IsBusy) //再判断是浏览器是否繁忙                  
                    {
                        i = i + 1;
                        if (i == 2)
                        {
                            sUrl = webBrowser1.Url.ToString();
                            if (sUrl.Contains("res")) //这是判断没有网络的情况下                           
                            {
                                return false;
                            }
                            else
                            {
                                return true;
                            }
                        }
                        continue;
                    }
                    i = 0;
                }
            }
        }
        #endregion

        #region 根据天猫商品地址获取商品信息+taoModel GetInfoByTmallUrl(string TmallUrl)
        /// <summary>
        /// 根据天猫商品地址获取商品信息
        /// </summary>
        ///<param name="TmallUrl">天猫地址</param>
        /// <returns>商品实体信息</returns>
        private static TaoModel GetInfoByTmallUrl(string TmallUrl)
        {
            TaoModel taoModel = new TaoModel();
            string Imgstr, str = "";
            str = GetStrByUrl(TmallUrl, "gb2312");
            Regex myRegex = new Regex("(?<=descUrl\":\").+(?=\",\"fetchDcUrl\")");//指定其正则验证式
            Regex imgaeRegex = new Regex("http://img.+60x60q90.jpg|https://img.+60x60q90.jpg|//img.+60x60q90.jpg");//商品图片
            Regex detailimgRegex = new Regex("https://img\\S+jpg|http://img\\S+jpg");//商品详细图片
            Regex ZkPriceRegex = new Regex("(?<=\"comboPrice\":\").+(?=\",\"defaultPromType\")");//折扣后价格
            Regex PriceRegex = new Regex("(?<=\"reservePrice\":\").+(?=\",\"rootCatId\")");//默认价格
            Regex shopNameRegex = new Regex("(?<=\"sellerNickName\":\").+(?=\",\"spuId\")");//店铺名称
            Regex titleRegex = new Regex("(?<=\"title\":\").+(?=\",\"userId\":\")");
            Regex PriceNowRegex = new Regex("");
            string detailImg = myRegex.Match(str).Value;//从指定内容中匹配字符串
            MatchCollection matchs = imgaeRegex.Matches(str, 0);
            string imgUrl = "";
            foreach (Match mat in matchs)
            {
                string tempmat = mat.Value;
                //tempmat = "http:" + tempmat;
                if (!tempmat.StartsWith("http"))
                {
                    tempmat = "http:"+tempmat;
                }
                tempmat = tempmat.Replace("_60x60q90.jpg", "");
                imgUrl += tempmat + "|";
            }
            string price = PriceRegex.Match(str).Value;
            string shopname = HttpUtility.UrlDecode(shopNameRegex.Match(str).Value);
            string title = titleRegex.Match(str).Value;
            //imgUrl = "商品图片："+imgUrl.Substring(0,imgUrl.Length-12);
            Imgstr = GetStrByUrl("http:" + detailImg,"gb2312").Substring(10);
            MatchCollection matches1 = detailimgRegex.Matches(Imgstr, 0);
            string DetailimgUrl = "";
            foreach (Match mat in matches1)
            {
                DetailimgUrl += mat.Value + "|";
            }
            taoModel.ProductName = title;
            taoModel.ShopName = shopname;
            taoModel.ProductPrice = price;
            taoModel.ThumImg = imgUrl;
            taoModel.DetailImg = DetailimgUrl;
            taoModel.TypeName = "天猫";
            return taoModel;
        }
        #endregion

        #region 根据淘宝商品地址获取商品信息+string GetInfoByTaobaoUrl(string TaobaoUrl)
        /// <summary>
        /// 根据淘宝商品地址获取商品信息
        /// </summary>
        /// <param name="TaobaoUrl">淘宝商品地址</param>
        /// <returns>淘宝商品信息</returns>
        private static TaoModel GetInfoByTaobaoUrl(string TaobaoUrl)
        {
            TaoModel taoModel = new TaoModel();
            string Imgstr, str = "";
            str = GetStrByUrl(TaobaoUrl, "gb2312");
            Regex myRegex = new Regex("(?<=location\\.protocol===\'http:\' \\? \').+(?=' :)");//指定其正则验证式
            Regex detailimgRegex = new Regex("https://img\\S+jpg|http://img\\S+jpg");//商品详细图片
            Regex imgaeRegex = new Regex("(?<=auctionImages    : \\[).+(?=])");//商品图片
            Regex PriceRegex = new Regex("(?<=price:).+(?=,)");//默认价格
            Regex shopNameRegex = new Regex("(?<=sellerNick:\").+(?=\")");//店铺名称
            Regex titleRegex = new Regex("(?<=title.).+(?=-淘宝网)");//商品名称
            string detailImg = myRegex.Match(str).Value.Replace("\"", "").Replace("'", "").Replace(":", "").Trim();//从指定内容中匹配字符串
            string imgUrl = imgaeRegex.Match(str).Value;
            MatchCollection matchs = imgaeRegex.Matches(str, 0);
            imgUrl=imgUrl.Replace("\"", "").Replace(",", "|").Replace("//","http://").Trim();
            string price = PriceRegex.Match(str).Value;
            string shopname = HttpUtility.UrlDecode(shopNameRegex.Match(str).Value);
            string title = titleRegex.Match(str).Value;
            //imgUrl = "商品图片："+imgUrl.Substring(0,imgUrl.Length-12);
            Imgstr =GetStrByUrl("http:" + detailImg,"gb2312");
            MatchCollection matches1 = detailimgRegex.Matches(Imgstr, 0);
            string DetailimgUrl = "";
            foreach (Match mat in matches1)
            {
                DetailimgUrl += mat.Value + "|";
            }
            taoModel.ProductName = title;
            taoModel.ShopName = shopname;
            taoModel.ProductPrice = price;
            taoModel.ThumImg = imgUrl;
            taoModel.DetailImg = DetailimgUrl;
            taoModel.TypeName = "淘宝";
            return taoModel;
        }
        #endregion

        #region 根据阿里巴巴商品地址获取商品信息+TaoModel GetInfoByAli(string AliUrl)
        /// <summary>
        /// 根据阿里巴巴商品地址获取商品信息
        /// </summary>
        /// <param name="AliUrl"></param>
        /// <returns></returns>
        public static TaoModel GetInfoByAli(string AliUrl)
        {
            TaoModel taoModel = new TaoModel();
            StringBuilder str = new StringBuilder();
            string Imgstr = "";
            str = GetStrByBorwserUrl(AliUrl);
            Regex myRegex = new Regex("(?<=data-tfs-url=\\\").+(?=\\\" data-enable)");//指定其正则验证式
            Regex imgaeRegex = new Regex("https://\\S+.alicdn.com/.+.400.jpg|http://\\S+.alicdn.com/.+.400.jpg|//\\S+.alicdn.com/.+.400.jpg");//商品图片
            Regex detailimgRegex = new Regex("https://\\S+.alicdn.com\\S+jpg|http://\\S+.alicdn.com\\S+jpg|//\\S+.alicdn.com\\S+jpg");//商品详细图片
            Regex ZkPriceRegex = new Regex("(?<=\"comboPrice\":\").+(?=\",\"defaultPromType\")");//折扣后价格
            Regex PriceRegex = new Regex("(?<=\"reservePrice\":\").+(?=\",\"rootCatId\")");//默认价格
            Regex shopNameRegex = new Regex("(?<=\"sellerNickName\":\").+(?=\",\"spuId\")");//店铺名称
            Regex titleRegex = new Regex("(?<=class=\"d-title\">).+(?=</h1>)");
            Regex PriceNowRegex = new Regex("");
            string detailImg = myRegex.Match(str.ToString()).Value;//从指定内容中匹配字符串
            MatchCollection matchs = imgaeRegex.Matches(str.ToString(), 0);
            string imgUrl = "";
            foreach (Match mat in matchs)
            {
                string tempmat = mat.Value;
                //tempmat = "http:" + tempmat;
                if (!tempmat.StartsWith("http"))
                {
                    tempmat = "http:" + tempmat;
                }
                tempmat = tempmat.Replace(".400x400", "");
                if (!imgUrl.Contains(tempmat))
                {
                    imgUrl += tempmat + "|";
                }
            }
            string price = PriceRegex.Match(str.ToString()).Value;
            string shopname = HttpUtility.UrlDecode(shopNameRegex.Match(str.ToString()).Value);
            string title = titleRegex.Match(str.ToString()).Value;
            //imgUrl = "商品图片："+imgUrl.Substring(0,imgUrl.Length-12);
            Imgstr = GetStrByBorwserUrl(detailImg).ToString();
            MatchCollection matches1 = detailimgRegex.Matches(Imgstr, 0);
            string DetailimgUrl = "";
            foreach (Match mat in matches1)
            {
                string tempmat = mat.Value;
                if (!tempmat.StartsWith("http"))
                {
                    tempmat = "http:" + tempmat;
                }
                if (!DetailimgUrl.Contains(tempmat))
                {
                    DetailimgUrl += tempmat + "|";
                }
            }
            taoModel.ProductName = title;
            taoModel.ShopName = shopname;
            taoModel.ProductPrice = price;
            taoModel.ThumImg = imgUrl;
            taoModel.DetailImg = DetailimgUrl;
            taoModel.TypeName = "阿里巴巴";
            return taoModel;
        }
        #endregion

        #region  根据京东商品地址获取商品信息+TaoModel GetInfoByJd(string JdUrl)
        /// <summary>
        /// 根据京东商品地址获取商品信息
        /// </summary>
        /// <param name="JdUrl"></param>
        /// <returns></returns>
        public static TaoModel GetInfoByJd(string JdUrl)
        {
            TaoModel taoModel = new TaoModel();
            string Imgstr, str = "";
            str = GetStrByUrl(JdUrl, "gb2312");
            Regex titleRegex = new Regex("(?<=title.).+(?=-京东)");//商品名称
            Regex imgRegex = new Regex("(?<=data-url=')\\S+.jpg|(?<=data-url=')\\S+.png");//获取商品图片
            Regex detailImgRegex = new Regex("(?<=desc: ')\\S+(?=',)");//商品详细图片地址
            Regex dImgRegex = new Regex("//\\S+.jpg|//\\S+.png");//所有详细图片

            string imgUrl = "";
            MatchCollection mact = imgRegex.Matches(str);
            foreach (Match mt in mact)
            {
                imgUrl += string.Concat("http://img13.360buyimg.com/n0/", mt.Value, "|");
            }
            string title = titleRegex.Match(str).Value;

            string detailImg = detailImgRegex.Match(str).Value;

            Imgstr = GetStrByUrl("http:" + detailImg, "gb2312");
            MatchCollection matches1 = dImgRegex.Matches(Imgstr, 0);
            string DetailimgUrl = "";
            foreach (Match mat in matches1)
            {
                DetailimgUrl += string.Concat("http:", mat.Value, "|");
            }
            taoModel.ProductName = title;
            taoModel.ProductPrice = "";
            taoModel.ShopName = "";
            taoModel.ThumImg = imgUrl;
            taoModel.DetailImg = DetailimgUrl;
            taoModel.TypeName = "京东";
            return taoModel;
        } 
        #endregion

        #region 保存图片+void Get_img(string url, string saveFileName)
        /// <summary>
        /// 保存图片
        /// </summary>
        /// <returns></returns>
        public static void Get_img(string url, string saveFileName)
        {
            Bitmap img = null;
            HttpWebRequest req;
            HttpWebResponse res = null;
            try
            {
                System.Uri httpUrl = new System.Uri(url);
                req = (HttpWebRequest)(WebRequest.Create(httpUrl));
                req.Timeout = 180000; //设置超时值10秒
                req.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)"; ;
                req.Accept = "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*";
                req.Method = "GET";
                res = (HttpWebResponse)(req.GetResponse());
                img = new Bitmap(res.GetResponseStream());//获取图片流                
                img.Save(saveFileName, ImageFormat.Jpeg);//随机名
            }

            catch (Exception ex)
            {
                string aa = ex.Message;
            }
            finally
            {
                if (res != null)
                {
                    res.Close();
                }
            }
        } 
        #endregion

        #region 根据地址判断是否有网络+bool IsWebResourceAvailable(string webResourceAddress)
        /// <summary>
        /// 根据地址判断是否有网络
        /// </summary>
        /// <param name="webResourceAddress"></param>
        /// <returns></returns>
        public static bool IsWebResourceAvailable(string webResourceAddress)
        {
            if (string.IsNullOrEmpty(webResourceAddress))
            {
                webResourceAddress = "http://www.baidu.com";
            }
            try
            {
                HttpWebRequest req = (HttpWebRequest)WebRequest.CreateDefault(new Uri(webResourceAddress));
                req.Method = "HEAD";
                req.Timeout = 1000;
                HttpWebResponse res = (HttpWebResponse)req.GetResponse();
                return (res.StatusCode == HttpStatusCode.OK);
            }
            catch (WebException wex)
            {
                System.Diagnostics.Trace.Write(wex.Message);
                return false;
            }
        } 
        #endregion

    }

}
