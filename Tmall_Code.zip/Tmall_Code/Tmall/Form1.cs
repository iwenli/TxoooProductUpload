﻿using System;
using System.Text.RegularExpressions;
using System.Text;
using System.Windows.Forms;
using TaoDal;
using System.IO;
using System.Threading;

namespace Tmall
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        TaoModel tmodel = new TaoModel();
        string prdpath = "", detailpath = "", folderpath="",rootpath="";
        private void btnGet_Click(object sender, EventArgs e)
        {
            btnGet.Enabled = false;
            if (string.IsNullOrEmpty(txtUrl.Text))
            {
                MessageBox.Show("请填写天猫/淘宝/阿里巴巴商品详细页地址", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtUrl.Focus();
                btnGet.Enabled = true;
                return;
            }
            if (!TaoDal.TaoApi.IsWebResourceAvailable(""))//判断是否有网络
            {
                MessageBox.Show("网络异常或繁忙，请稍候重试Ծ‸Ծ", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btnGet.Enabled = true;
                return;
            }
            try
            {
                tmodel = TaoApi.GetItemByUrl(txtUrl.Text.Trim());
                if (tmodel != null)
                {
                    tmodel.ProductName = tmodel.ProductName.Replace(":", "").Replace("\\", "").Replace("/", "").Replace("*", "");
                   if ((tmodel.ThumImg + "").Length < 10)
                   {
                       MessageBox.Show("暂未获取到图片信息,请检查填写地址或稍后重试", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                       txtUrl.Select();
                       btnGet.Enabled = true;
                       return;
                   }
                   FolderBrowserDialog fbd = new FolderBrowserDialog();
                   fbd.ShowNewFolderButton = true;
                   fbd.Description = "已获取到图片信息，请选择保存目录";
                   if (fbd.ShowDialog() == DialogResult.OK)
                   {
                       string rootname = fbd.SelectedPath;
                       rootpath = rootname;
                   }
                   else
                   {
                       btnGet.Enabled = true;
                       return;
                   }
                   if (!Directory.Exists(rootpath))
                   {
                       Directory.CreateDirectory(rootpath);
                   }
                    folderpath = tmodel.ProductName;
                    if (Directory.Exists(rootpath + "/" + folderpath))
                    {
                        if (!(MessageBox.Show("已存在该产品信息，是否覆盖", "消息提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK))
                        {
                            btnGet.Enabled = true;
                            return;
                        }
                    }
                    else
                    {
                        Directory.CreateDirectory(rootpath + "/" + folderpath);
                    }
                    prdpath = "产品主图";
                    detailpath = "产品详细图片";
                    Directory.CreateDirectory(rootpath + "/" + folderpath + "/" + prdpath);
                    Directory.CreateDirectory(rootpath + "/" + folderpath + "/" + detailpath);
                    ThreadStart threastart1 = new ThreadStart(ProcessPrdImg);
                    Thread thread1 = new Thread(threastart1);
                    thread1.Start();
                    ThreadStart threastart2 = new ThreadStart(ProcessDetailImg);
                    Thread thread2 = new Thread(threastart2);
                    thread2.Start();
                    string txtPath = rootpath + "/" + folderpath + "/产品信息.txt";
                    string[] someInfo = { "产品名称:" + tmodel.ProductName, "", "产品地址：" + txtUrl.Text };
                    File.WriteAllLines(txtPath, someInfo, Encoding.UTF8);
                    string filePath = rootpath + "\\" + tmodel.ProductName;
                    if (MessageBox.Show(string.Concat("产品信息已成功保存至：" ,filePath,",是否立即查看？"), "消息提示", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information)==DialogResult.Yes)
                    {
                        System.Diagnostics.Process.Start(filePath);
                    }
                }
                else
                {
                    MessageBox.Show("暂未获取到相关信息", "消息提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"消息提示",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            txtUrl.Focus();
            txtUrl.SelectAll();
            btnGet.Enabled = true;
        }

        private void ProcessPrdImg()
        {
            Thread.Sleep(1);
            int i = 0;
            foreach (string s in tmodel.ThumImg.Split('|'))
            {
                if (!string.IsNullOrEmpty(s))
                {
                    i++;
                    TaoApi.Get_img(s, rootpath + "/" + folderpath + "/" + prdpath + "/" + i + ".jpg");
                }
            }
        }

        private void ProcessDetailImg()
        {
            Thread.Sleep(1);
            int i = 0;
            foreach (string s in tmodel.DetailImg.Split('|'))
            {
                if (!string.IsNullOrEmpty(s))
                {
                    i++;
                    TaoApi.Get_img(s, rootpath + "/" + folderpath + "/" + detailpath + "/" + i + ".jpg");
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.jinliniuan.com/archives/1244.html");
        }

        //鼠标点击时，如果剪贴板有匹配的url并且地址栏为空，赋值,不为空全选
        private void txtUrl_Click(object sender, EventArgs e)
        {
            Regex urlReg = new Regex("item.taobao.com|detail.tmall.com|detail.1688.com|item.jd.com");//url
            if (string.IsNullOrEmpty(txtUrl.Text))
            {
                string getTxt = Clipboard.GetText();
                if (urlReg.IsMatch(getTxt))
                {
                    txtUrl.Text = getTxt;
                }
            }
            else
            {
                txtUrl.SelectAll();
            }
        }

        private void topToolStripMenuItem_Click(object sender, EventArgs e)
        {
            topToolStripMenuItem.Text = topToolStripMenuItem.Text == "置顶" ? "取消置顶" : "置顶";
            TopMost = !TopMost;
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.jinliniuan.com/contact/82.html");
        }

        private void raqToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.jinliniuan.com/archives/1244.html");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void notifyIcon1_MouseClick(object sender, MouseEventArgs e)
        {
            WindowState = FormWindowState.Normal;
        }
    }
}
